package org.launchcode.helloexercise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloExerciseApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloExerciseApplication.class, args);
	}

}
